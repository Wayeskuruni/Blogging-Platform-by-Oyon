const API_ENDPOINT = "http://localhost:5000"

export const getAPIUri = (path)=> API_ENDPOINT+path